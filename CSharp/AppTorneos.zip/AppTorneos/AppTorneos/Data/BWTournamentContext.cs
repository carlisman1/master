﻿using AppTorneos.Models;
using Microsoft.EntityFrameworkCore;

namespace AppTorneos.Data
{
    public class BWTournamentContext: DbContext
    {
        public BWTournamentContext(DbContextOptions<BWTournamentContext> options) 
        : base(options){ }

        public DbSet<User> Usuarios { get; set; }
    }
}
