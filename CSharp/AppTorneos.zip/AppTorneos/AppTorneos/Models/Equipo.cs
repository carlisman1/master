﻿namespace AppTorneos.Models
{
    public class Equipo
    {
    }
}
